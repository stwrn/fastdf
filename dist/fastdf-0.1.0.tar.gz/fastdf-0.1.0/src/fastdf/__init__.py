from .core import FastDataFrame as fdf

__all__ = ['fdf']
__version__ = '0.1.0'
